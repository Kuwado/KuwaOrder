package fx.makerequest;

import model.Product;

public interface MRMyListener {
    public void onClickListener(Product product);
}
