package solution;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableView;

import java.util.List;

public class Paginator<T> {

    public static <T> void setPagination(TableView<T> table, Pagination pagination, ObservableList<T> items, int number) {
        int totalPages = (items.size() + number - 1) / number;
        pagination.setPageCount(totalPages);
        pagination.setPageFactory(pageIndex -> {
            int fromIndex = pageIndex * number;
            int toIndex = Math.min(fromIndex + number, items.size());
            ObservableList<T> currentPageItems = FXCollections.observableArrayList(items.subList(fromIndex, toIndex));
            table.setItems(currentPageItems);
            return table;
        });
    }
}
